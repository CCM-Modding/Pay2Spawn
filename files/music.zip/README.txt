We don't claim ownership of anything in this folder.
All copyright to the original creators.

Distributed under fair use where applicable, common sense anywhere else.